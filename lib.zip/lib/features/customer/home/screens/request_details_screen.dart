import 'package:flutter/material.dart';
import '../../../../core/shared/widgets/skeleton_list.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/network/api_error_text.dart';
import '../../../../core/shared/cubit/api_state.dart';
import '../../../offers/models/offer_preview_mapper.dart';
import '../../../requests/cubit/requests_cubit.dart';
import '../../../requests/models/request_model.dart';
import '../../../requests/models/request_preview.dart';
import '../../../../config/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/shared/widgets/buttons/app_back_button.dart';
import '../../../../core/shared/widgets/property_image_strip.dart';
import '../../../../core/shared/widgets/section_card.dart';
import '../../../../core/shared/widgets/date_time_label.dart';
import '../../../../generated/locale_keys.g.dart';
import '../models/offer_preview.dart';
import '../widgets/offer_status_badge.dart';
import '../models/property_request.dart';

/// Full detail view for a single client request + a preview of the
/// offers received on it, matching the Figma design (status badge,
/// budget bento card, spec grid, notes, inline offer previews, and a
/// bottom edit/pause action bar). Opened from a [RequestCard] on the
/// home tab or from search results.
///
/// Takes the request's id through `settings.arguments` (see
/// [AppRoutes.requestDetails]) and looks it up from the mock data —
/// swap [findPropertyRequestById] for a repository call once the
/// backend is wired up.
class RequestDetailsScreen extends StatefulWidget {
  final PropertyRequest request;

  const RequestDetailsScreen({super.key, required this.request});

  @override
  State<RequestDetailsScreen> createState() => _RequestDetailsScreenState();
}

class _RequestDetailsScreenState extends State<RequestDetailsScreen> {
  @override
  void initState() {
    super.initState();
    // Loads the request together with the offers marketers sent on it.
    context.read<RequestsCubit>().open(widget.request.id);
  }

  Future<bool> _confirm(String title, String desc, String action, Color color) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(title, style: AppTextStyles.heading4),
        content: Text(desc, style: AppTextStyles.bodyRegular, textAlign: TextAlign.start),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: Text(LocaleKeys.cancelButton.tr())),
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(true), child: Text(action, style: TextStyle(color: color))),
        ],
      ),
    );
    return ok == true;
  }

  void _error(RequestsCubit cubit) => ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(cubit.state.error!.text), backgroundColor: AppColors.error),
      );

  Future<void> _close() async {
    final cubit = context.read<RequestsCubit>();
    final yes = await _confirm(LocaleKeys.closeRequestConfirmTitle.tr(), LocaleKeys.closeRequestConfirmDesc.tr(),
        LocaleKeys.closeRequestButton.tr(), AppColors.primaryDark);
    if (!yes) return;
    if (!await cubit.closeRequest(widget.request.id) && mounted) _error(cubit);
  }

  Future<void> _delete() async {
    final cubit = context.read<RequestsCubit>();
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final yes = await _confirm(LocaleKeys.deleteRequestConfirmTitle.tr(), LocaleKeys.deleteRequestConfirmDesc.tr(),
        LocaleKeys.deleteRequestButton.tr(), AppColors.error);
    if (!yes) return;
    if (await cubit.delete(widget.request.id)) {
      nav.pop();
      messenger.showSnackBar(SnackBar(content: Text(LocaleKeys.requestDeleted.tr())));
    } else if (mounted) {
      _error(cubit);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.locale.languageCode;

    return BlocConsumer<RequestsCubit, ApiState<RequestModel>>(
      // Make the loaded offers findable by the offer details screen.
      listenWhen: (a, b) => b.selected?.id == widget.request.id && a.selected != b.selected,
      listener: (context, state) =>
          setOfferPreviews(widget.request.id, [for (final o in state.selected!.offers) o.toPreview(lang)]),
      builder: (context, state) {
        final loaded = state.selected?.id == widget.request.id ? state.selected : null;
        final request = loaded?.toPreview() ?? widget.request;
        final offers = loaded == null ? <OfferPreview>[] : [for (final o in loaded.offers) o.toPreview(lang)];
        final loading = loaded == null && state.isLoading;
        return _buildScaffold(context, request, offers, loading);
      },
    );
  }

  Widget _buildScaffold(BuildContext context, PropertyRequest request, List<OfferPreview> offers, bool loading) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(LocaleKeys.requestDetailsTitle.tr(), style: AppTextStyles.heading4.copyWith(color: AppColors.primaryDark)),
        leading: const AppBackButton(),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => context.read<RequestsCubit>().open(request.id),
          child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          children: [
            _StatusAndTitleCard(request: request),
            const SizedBox(height: 16),
            _BudgetCard(priceRange: request.priceRange),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: _SpecCard(icon: Icons.bathtub_outlined, label: LocaleKeys.specBathrooms.tr(), value: '${request.bathrooms}')),
                const SizedBox(width: 16),
                Expanded(child: _SpecCard(icon: Icons.bed_outlined, label: LocaleKeys.specRooms.tr(), value: '${request.rooms}')),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: _SpecCard(icon: Icons.brush_outlined, label: LocaleKeys.specFinishing.tr(), value: request.finishing)),
                const SizedBox(width: 16),
                Expanded(child: _SpecCard(icon: Icons.straighten, label: LocaleKeys.specArea.tr(), value: request.area)),
              ],
            ),
            const SizedBox(height: 16),
            _NotesCard(description: request.description),
            const SizedBox(height: 24),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(6)),
                  child: Text('${offers.isEmpty ? request.offersCount : offers.length}', style: AppTextStyles.heading4),
                ),
                const SizedBox(width: 8),
                Text(LocaleKeys.viewReceivedOffers.tr(), style: AppTextStyles.heading4),
              ],
            ),
            const SizedBox(height: 16),
            if (loading)
              const SkeletonList(count: 2)
            else if (offers.isEmpty)
              SectionCard(child: Text(LocaleKeys.noOffersYet.tr(), style: AppTextStyles.bodyRegular, textAlign: TextAlign.center))
            else
              ...offers.map((o) => Padding(padding: const EdgeInsets.only(bottom: 12), child: _OfferPreviewCard(offer: o))),
          ],
        ),
        ),
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
        decoration: const BoxDecoration(color: AppColors.background, border: Border(top: BorderSide(color: AppColors.border))),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => Navigator.pushNamed(context, AppRoutes.editRequest, arguments: request.id),
                      icon: const Icon(Icons.edit_outlined, size: 18),
                      label: Text(LocaleKeys.editRequestButton.tr()),
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary, foregroundColor: Colors.white),
                    ),
                  ),
                  if (request.status != PropertyRequestStatus.closed) ...[
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _close,
                        icon: const Icon(Icons.lock_outline, size: 16),
                        label: Text(LocaleKeys.closeRequestButton.tr()),
                        style: OutlinedButton.styleFrom(foregroundColor: AppColors.primaryDark, side: const BorderSide(color: AppColors.primaryDark)),
                      ),
                    ),
                  ],
                ],
              ),
              TextButton.icon(
                onPressed: _delete,
                icon: const Icon(Icons.delete_outline, size: 18, color: AppColors.error),
                label: Text(LocaleKeys.deleteRequestButton.tr(), style: AppTextStyles.bodySmall.copyWith(color: AppColors.error)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusAndTitleCard extends StatelessWidget {
  final PropertyRequest request;
  const _StatusAndTitleCard({required this.request});

  @override
  Widget build(BuildContext context) {
    final (statusLabel, statusColor) = switch (request.status) {
      PropertyRequestStatus.open => (LocaleKeys.statusOpen.tr(), AppColors.warning),
      PropertyRequestStatus.offersReceived => (LocaleKeys.statusOffersReceived.tr(), AppColors.primary),
      PropertyRequestStatus.closed => (LocaleKeys.statusClosed.tr(), AppColors.textMuted),
    };

    return SectionCard(
      padding: const EdgeInsets.all(17),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(color: statusColor, borderRadius: BorderRadius.circular(999)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(statusLabel, style: AppTextStyles.badgeTracked.copyWith(color: Colors.white)),
                    const SizedBox(width: 4),
                    Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
                  ],
                ),
              ),
              const Spacer(),
              Text('#${request.id}', style: AppTextStyles.bodySmall),
            ],
          ),
          const SizedBox(height: 8),
          Text(request.title, style: AppTextStyles.heading1, textAlign: TextAlign.start),
          if (request.propertyType.isNotEmpty) ...[
            const SizedBox(height: 8),
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: AppColors.primaryLight, borderRadius: BorderRadius.circular(999)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.apartment, size: 14, color: AppColors.primaryDark),
                    const SizedBox(width: 6),
                    Text(request.propertyType, style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryDark)),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 8),
          if (request.createdAt != null) ...[
            Align(alignment: AlignmentDirectional.centerStart, child: DateTimeLabel(date: request.createdAt)),
            const SizedBox(height: 6),
          ],
          Row(
            children: [
              Expanded(child: Text(request.location, style: AppTextStyles.bodySmall, textAlign: TextAlign.start)),
              const SizedBox(width: 8),
              const Icon(Icons.location_on_outlined, size: 15, color: AppColors.textSecondary),
            ],
          ),
        ],
      ),
    );
  }
}

class _BudgetCard extends StatelessWidget {
  final String priceRange;
  const _BudgetCard({required this.priceRange});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Stack(
        children: [
          SectionCard(
            padding: const EdgeInsets.all(17),
            child: Column(
              children: [
                Text(LocaleKeys.suggestedBudgetLabel.tr(), style: AppTextStyles.bodySmall),
                const SizedBox(height: 4),
                Text(priceRange, style: AppTextStyles.priceLarge),
              ],
            ),
          ),
          PositionedDirectional(
            top: -16,
            end: -16,
            child: Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.2), shape: BoxShape.circle),
            ),
          ),
        ],
      ),
    );
  }
}

class _SpecCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _SpecCard({required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      padding: const EdgeInsets.all(13),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: const BoxDecoration(color: AppColors.background, shape: BoxShape.circle),
            child: Icon(icon, size: 18, color: AppColors.textSecondary),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(label, style: AppTextStyles.badgeTracked.copyWith(color: AppColors.textSecondary, letterSpacing: 0)),
                const SizedBox(height: 2),
                Text(
                  value.isNotEmpty ? value : '—',
                  style: AppTextStyles.heading4,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NotesCard extends StatelessWidget {
  final String description;
  const _NotesCard({required this.description});

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      padding: const EdgeInsets.all(17),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Text(LocaleKeys.requestDescriptionTitle.tr(), style: AppTextStyles.heading3, textAlign: TextAlign.start),
          const SizedBox(height: 8),
          Text(
            description.isNotEmpty ? description : LocaleKeys.noDescriptionAvailable.tr(),
            style: AppTextStyles.bodyRegular,
            textAlign: TextAlign.start,
          ),
        ],
      ),
    );
  }
}

class _OfferPreviewCard extends StatelessWidget {
  final OfferPreview offer;
  const _OfferPreviewCard({required this.offer});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => Navigator.pushNamed(context, AppRoutes.offerDetails, arguments: offer.id),
      child: SectionCard(
        padding: const EdgeInsets.all(17),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                alignment: Alignment.center,
                decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
                child: const Icon(Icons.person, color: AppColors.primaryDark),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      children: [
                        Text(offer.timeAgo, style: AppTextStyles.caption),
                        const Spacer(),
                        Text(offer.marketerName, style: AppTextStyles.heading4),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [OfferStatusBadge(status: offer.status)],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(LocaleKeys.reviewsCountLabel.tr(args: ['${offer.reviewsCount}']), style: AppTextStyles.caption),
                        const SizedBox(width: 4),
                        Text('${offer.rating}', style: AppTextStyles.caption.copyWith(color: AppColors.warning, fontWeight: FontWeight.bold)),
                        const SizedBox(width: 4),
                        const Icon(Icons.star, size: 12, color: AppColors.warning),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      offer.message,
                      style: AppTextStyles.bodySmall,
                      textAlign: TextAlign.start,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (offer.propertyTitle != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: AppColors.background, borderRadius: BorderRadius.circular(10)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.home_work_outlined, size: 16, color: AppColors.primaryDark),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          offer.propertyTitle!,
                          style: AppTextStyles.bodySmall.copyWith(color: AppColors.textPrimary, fontWeight: FontWeight.bold),
                          textAlign: TextAlign.start,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  // Every photo the marketer attached to this property
                  // shows here — not just a cover — and tapping any one
                  // opens the full-screen swipeable gallery.
                  PropertyImageStrip(imagePaths: offer.propertyImagePaths, thumbnailSize: 76),
                ],
              ),
            ),
          ],
        ],
      ),
      ),
    );
  }
}
