import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../config/router/app_router.dart';
import '../../../../core/shared/cubit/api_state.dart';
import '../../../../core/shared/widgets/customer/categories_row.dart';
import '../../../../core/shared/widgets/customer/section_header.dart';
import '../../../../core/shared/widgets/fields/custom_search_bar.dart';
import '../../../../core/shared/widgets/top_bar.dart';
import '../../../../core/shared/widgets/buttons/app_primary_button.dart';
import '../../../../core/data/locations.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../listings/cubit/listings_cubit.dart';
import '../../../listings/data/listings_repository.dart';
import '../../../listings/models/listing_model.dart';
import '../../../listings/widgets/listings_message.dart';
import '../widgets/listing_card.dart';
import '../../../../generated/locale_keys.g.dart';

/// Content for the "Home" tab only — no Scaffold/bottom nav here.
/// [ClientShellScreen] owns those and swaps this in via BottomBarCubit.
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  final ListingsCubit _listings = ListingsCubit(ListingsRepository());
  int? _cityId;
  int? _districtId;

  @override
  void initState() {
    super.initState();
    // Saved listings, so the hearts show the right state.
    context.read<FavoritesCubit>().load();
    _listings.load();
  }

  @override
  void dispose() {
    _listings.close();
    super.dispose();
  }

  Future<void> _refresh() => _listings.load(ListingFilter(cityId: _cityId, districtId: _districtId));

  /// Label on the location chip: the district, else the city, else "all areas".
  String _locationLabel(String lang) {
    final ar = lang == 'ar';
    if (_districtId != null) {
      final d = Locations.districts.firstWhere((d) => d.id == _districtId);
      return ar ? d.nameAr : d.nameEn;
    }
    if (_cityId != null) {
      final c = Locations.cities.firstWhere((c) => c.id == _cityId);
      return ar ? c.nameAr : c.nameEn;
    }
    return LocaleKeys.locationAll.tr();
  }

  Future<void> _pickLocation() async {
    final result = await showModalBottomSheet<({int? cityId, int? districtId})>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => _LocationSheet(cityId: _cityId, districtId: _districtId),
    );
    if (result == null) return;
    setState(() {
      _cityId = result.cityId;
      _districtId = result.districtId;
    });
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final lang = context.locale.languageCode;
    return BlocProvider.value(
      value: _listings,
      child: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              TopBar(locationLabel: _locationLabel(lang), onLocationTap: _pickLocation),
              const SizedBox(height: 24),
              CustomSearchBar(
                onTap: () => Navigator.pushNamed(context, AppRoutes.search),
                searchText: LocaleKeys.searchPlaceholder.tr(),
              ),
              const SizedBox(height: 24),
              CategoriesRow(
                onCategoryTap: (category) => Navigator.pushNamed(context, AppRoutes.search, arguments: category),
              ),
              const SizedBox(height: 24),
              SectionHeader(
                title: LocaleKeys.marketerListingsTitle.tr(),
                onViewAllTap: () => Navigator.pushNamed(context, AppRoutes.search),
              ),
              const SizedBox(height: 16),
              // Properties posted by marketers (sale / rent), from `GET listings`.
              BlocBuilder<ListingsCubit, ApiState<ListingModel>>(
                builder: (context, state) {
                  final message = ListingsMessage.of(state, _refresh);
                  if (message != null) return message;
                  return Column(
                    children: [
                      for (final l in state.items)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 16),
                          child: ListingCard(
                            listing: l,
                            onTap: () => Navigator.pushNamed(context, AppRoutes.listingDetails, arguments: l.id),
                          ),
                        ),
                    ],
                  );
                },
              ),
              const SizedBox(height: 8),
              AppPrimaryButton(
                label: LocaleKeys.createRequestButton.tr(),
                icon: Icons.add,
                onPressed: () => Navigator.pushNamed(context, AppRoutes.createRequestLocation),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Bottom sheet: pick a city, then one of its districts (or the whole city).
class _LocationSheet extends StatefulWidget {
  final int? cityId;
  final int? districtId;
  const _LocationSheet({this.cityId, this.districtId});

  @override
  State<_LocationSheet> createState() => _LocationSheetState();
}

class _LocationSheetState extends State<_LocationSheet> {
  late int? _city = widget.cityId;

  Widget _row(String label, bool selected, VoidCallback onTap, {IconData? icon}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: selected ? AppColors.primaryLight : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        dense: true,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        leading: icon == null ? null : Icon(icon, size: 20, color: selected ? AppColors.primary : AppColors.textSecondary),
        title: Text(
          label,
          style: AppTextStyles.bodyRegular.copyWith(
            color: selected ? AppColors.primaryDark : AppColors.textPrimary,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        trailing: selected ? const Icon(Icons.check_circle, color: AppColors.primary, size: 20) : null,
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = context.locale.languageCode == 'ar';
    final districts = _city == null ? const <District>[] : Locations.districtsOf(_city!);

    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.75),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Text(LocaleKeys.locationPickTitle.tr(), style: AppTextStyles.heading3),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: _row(LocaleKeys.locationAll.tr(), _city == null && widget.districtId == null,
                  () => Navigator.pop(context, (cityId: null, districtId: null)),
                  icon: Icons.public),
            ),
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  for (final c in Locations.cities)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(
                        label: Text(ar ? c.nameAr : c.nameEn),
                        selected: _city == c.id,
                        showCheckmark: false,
                        selectedColor: AppColors.primary,
                        backgroundColor: AppColors.surface,
                        side: BorderSide(color: _city == c.id ? AppColors.primary : AppColors.border),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                        labelStyle: AppTextStyles.bodySmall.copyWith(
                          color: _city == c.id ? Colors.white : AppColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        onSelected: (_) => setState(() => _city = c.id),
                      ),
                    ),
                ],
              ),
            ),
            if (_city != null)
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  children: [
                    _row(LocaleKeys.locationWholeCity.tr(), widget.cityId == _city && widget.districtId == null,
                        () => Navigator.pop(context, (cityId: _city, districtId: null)),
                        icon: Icons.location_city_outlined),
                    for (final d in districts)
                      _row(ar ? d.nameAr : d.nameEn, widget.districtId == d.id,
                          () => Navigator.pop(context, (cityId: _city, districtId: d.id)),
                          icon: Icons.place_outlined),
                  ],
                ),
              )
            else
              const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
