import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/shared/widgets/app_property_image.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../generated/locale_keys.g.dart';
import '../../../../core/shared/cubit/api_state.dart';
import '../../../listings/cubit/listings_cubit.dart';
import '../../../listings/models/listing_model.dart';

/// A marketer's property (for sale / for rent) as the customer sees it.
class ListingCard extends StatelessWidget {
  final ListingModel listing;
  final VoidCallback? onTap;

  const ListingCard({super.key, required this.listing, this.onTap});

  @override
  Widget build(BuildContext context) {
    final lang = context.locale.languageCode;
    final price = listing.displayPrice == null
        ? ''
        : NumberFormat.decimalPattern(lang).format(listing.displayPrice);
    final suffix = !listing.isRent
        ? ''
        : ' ${listing.isDailyRent ? LocaleKeys.perDay.tr() : LocaleKeys.perMonth.tr()}';
    final priceText = price.isEmpty ? '' : '$price ${LocaleKeys.currency.tr()}$suffix';
    final marketer = listing.marketer;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Stack(
                children: [
                  listing.coverImageUrl == null
                      ? Container(
                          height: 150,
                          color: AppColors.primaryLight,
                          alignment: Alignment.center,
                          child: const Icon(Icons.apartment, size: 40, color: AppColors.primary),
                        )
                      : AppPropertyImage(path: listing.coverImageUrl!, height: 150, width: double.infinity),
                  PositionedDirectional(
                    top: 8,
                    end: 8,
                    child: _Pill(
                      text: listing.isRent ? LocaleKeys.listingForRent.tr() : LocaleKeys.listingForSale.tr(),
                      background: listing.isRent ? AppColors.primary : AppColors.primaryDark,
                      foreground: Colors.white,
                    ),
                  ),
                  if (listing.isNew)
                    PositionedDirectional(
                      top: 8,
                      start: 8,
                      child: _Pill(
                        text: LocaleKeys.newBadge.tr(),
                        background: AppColors.surface,
                        foreground: AppColors.primaryDark,
                      ),
                    ),
                  PositionedDirectional(bottom: 6, end: 6, child: FavoriteButton(listing: listing)),
                ],
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(listing.title, style: AppTextStyles.heading3),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        const Icon(Icons.place_outlined, size: 14, color: AppColors.textSecondary),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(listing.location(lang),
                              style: AppTextStyles.bodySmall, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 16,
                      runSpacing: 6,
                      children: [
                        if (listing.rooms != null) _Spec(icon: Icons.bed_outlined, value: '${listing.rooms}'),
                        if (listing.bathrooms != null) _Spec(icon: Icons.bathtub_outlined, value: '${listing.bathrooms}'),
                        if (listing.area != null)
                          _Spec(icon: Icons.straighten, value: '${listing.area!.round()} ${LocaleKeys.areaUnit.tr()}'),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(height: 1, color: AppColors.border),
                    const SizedBox(height: 12),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const Icon(Icons.person_outline_rounded, size: 16, color: AppColors.textSecondary),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            marketer?.fullName ?? '',
                            style: AppTextStyles.bodySmall,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        if ((marketer?.rating ?? 0) > 0) ...[
                          const Icon(Icons.star_rounded, size: 16, color: AppColors.warning),
                          const SizedBox(width: 2),
                          Text(marketer!.rating!.toStringAsFixed(1), style: AppTextStyles.caption),
                          const SizedBox(width: 12),
                        ],
                        Flexible(
                          child: Text(priceText, style: AppTextStyles.priceLarge, maxLines: 1, overflow: TextOverflow.ellipsis),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Heart on a listing: saves / removes it through the app-wide [FavoritesCubit].
class FavoriteButton extends StatelessWidget {
  final ListingModel listing;
  const FavoriteButton({super.key, required this.listing});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FavoritesCubit, ApiState<ListingModel>>(
      buildWhen: (a, b) => a.items.any((l) => l.id == listing.id) != b.items.any((l) => l.id == listing.id),
      builder: (context, state) {
        final saved = state.items.any((l) => l.id == listing.id);
        return Material(
          color: Colors.white,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => context.read<FavoritesCubit>().toggle(listing),
            child: Padding(
              padding: const EdgeInsets.all(7),
              child: Icon(
                saved ? Icons.favorite : Icons.favorite_border,
                size: 20,
                color: saved ? AppColors.error : AppColors.textSecondary,
              ),
            ),
          ),
        );
      },
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  final Color background;
  final Color foreground;
  const _Pill({required this.text, required this.background, required this.foreground});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: background, borderRadius: BorderRadius.circular(999)),
      child: Text(text, style: AppTextStyles.badgeTracked.copyWith(color: foreground, letterSpacing: 0)),
    );
  }
}

class _Spec extends StatelessWidget {
  final IconData icon;
  final String value;
  const _Spec({required this.icon, required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: AppColors.textSecondary),
        const SizedBox(width: 4),
        Text(value, style: AppTextStyles.bodySmall),
      ],
    );
  }
}
