import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import '../../../../core/data/locations.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../generated/locale_keys.g.dart';

/// What the location chip on the home screen says: the district, else the
/// city, else "all areas".
String locationLabel(int? cityId, int? districtId, String lang) {
  final ar = lang == 'ar';
  if (districtId != null) {
    final d = Locations.districts.firstWhere((d) => d.id == districtId);
    return ar ? d.nameAr : d.nameEn;
  }
  if (cityId != null) {
    final c = Locations.cities.firstWhere((c) => c.id == cityId);
    return ar ? c.nameAr : c.nameEn;
  }
  return LocaleKeys.locationAll.tr();
}

/// Opens [LocationSheet]; null when dismissed.
Future<({int? cityId, int? districtId})?> pickLocation(BuildContext context, {int? cityId, int? districtId}) {
  return showModalBottomSheet<({int? cityId, int? districtId})>(
    context: context,
    isScrollControlled: true,
    backgroundColor: AppColors.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
    builder: (_) => LocationSheet(cityId: cityId, districtId: districtId),
  );
}

/// Bottom sheet: pick a city, then one of its districts (or the whole city).
class LocationSheet extends StatefulWidget {
  final int? cityId;
  final int? districtId;
  const LocationSheet({this.cityId, this.districtId});

  @override
  State<LocationSheet> createState() => _LocationSheetState();
}

class _LocationSheetState extends State<LocationSheet> {
  late int? _city = widget.cityId;

  Widget _row(String label, bool selected, VoidCallback onTap, {IconData? icon}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      decoration: BoxDecoration(
        color: selected ? AppColors.primaryLight : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
      ),
      child: ListTile(
        dense: true,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        leading: icon == null ? null : Icon(icon, size: 20, color: selected ? AppColors.primary : AppColors.textSecondary),
        title: Text(
          label,
          style: AppTextStyles.bodyRegular.copyWith(
            color: selected ? AppColors.primaryDark : AppColors.textPrimary,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        trailing: selected ? const Icon(Icons.check_circle, color: AppColors.primary, size: 20) : null,
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final ar = context.locale.languageCode == 'ar';
    final districts = _city == null ? const <District>[] : Locations.districtsOf(_city!);

    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.75),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 10),
            Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Text(LocaleKeys.locationPickTitle.tr(), style: AppTextStyles.heading3),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: _row(LocaleKeys.locationAll.tr(), _city == null && widget.districtId == null,
                  () => Navigator.pop(context, (cityId: null, districtId: null)),
                  icon: Icons.public),
            ),
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  for (final c in Locations.cities)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(
                        label: Text(ar ? c.nameAr : c.nameEn),
                        selected: _city == c.id,
                        showCheckmark: false,
                        selectedColor: AppColors.primary,
                        backgroundColor: AppColors.surface,
                        side: BorderSide(color: _city == c.id ? AppColors.primary : AppColors.border),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                        labelStyle: AppTextStyles.bodySmall.copyWith(
                          color: _city == c.id ? Colors.white : AppColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        onSelected: (_) => setState(() => _city = c.id),
                      ),
                    ),
                ],
              ),
            ),
            if (_city != null)
              Flexible(
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  children: [
                    _row(LocaleKeys.locationWholeCity.tr(), widget.cityId == _city && widget.districtId == null,
                        () => Navigator.pop(context, (cityId: _city, districtId: null)),
                        icon: Icons.location_city_outlined),
                    for (final d in districts)
                      _row(ar ? d.nameAr : d.nameEn, widget.districtId == d.id,
                          () => Navigator.pop(context, (cityId: _city, districtId: d.id)),
                          icon: Icons.place_outlined),
                  ],
                ),
              )
            else
              const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
