import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

abstract class BottomBarState {}

class BottomBarInitial extends BottomBarState {}

class BottomBarIndexChanged extends BottomBarState {}

/// Holds the current tab index and the list of tab screens.
/// One instance is created per shell (client / marketer) with its
/// own `layouts`, via `BlocProvider` in `BottomBarScreen`.
class BottomBarCubit extends Cubit<BottomBarState> {
  BottomBarCubit(this.layouts) : super(BottomBarInitial());

  static BottomBarCubit get(BuildContext context) => BlocProvider.of<BottomBarCubit>(context);

  int currentIndex = 0;
  final List<Widget> layouts;

  void changeIndex(int index) {
    currentIndex = index;
    emit(BottomBarIndexChanged());
  }
}
