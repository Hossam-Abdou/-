import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../core/shared/widgets/app_back_button.dart';
import '../../../../core/shared/widgets/app_primary_button.dart';
import '../../../../core/shared/widgets/multi_image_picker_field.dart';
import '../../../../core/shared/widgets/validated_text_field.dart';
import '../../../../core/shared/widgets/property_type_chips.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../generated/locale_keys.g.dart';
import '../models/marketer_property.dart';

/// Add-property and edit-property share this one form: when
/// [existingProperty] is null it's add mode (empty fields, "Add
/// Property" submit); when it's provided the fields are pre-filled
/// and a delete option is shown ("Edit Property").
///
/// Submission is simulated: there's no backend yet, so this validates
/// the form, shows a success dialog, and pops back — swap `_submit`
/// for a real API call once [mockMarketerProperties] is replaced by a
/// repository.
class PropertyFormScreen extends StatefulWidget {
  final MarketerProperty? existingProperty;

  const PropertyFormScreen({super.key, this.existingProperty});

  @override
  State<PropertyFormScreen> createState() => _PropertyFormScreenState();
}

class _PropertyFormScreenState extends State<PropertyFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _titleController;
  late final TextEditingController _locationController;
  late final TextEditingController _areaController;
  late final TextEditingController _priceController;
  late String _selectedType;
  List<String> _imagePaths = [];
  bool _submitting = false;

  bool get _isEditMode => widget.existingProperty != null;

  @override
  void initState() {
    super.initState();
    final p = widget.existingProperty;
    _titleController = TextEditingController(text: p?.title ?? '');
    _locationController = TextEditingController(text: p?.location ?? '');
    _areaController = TextEditingController(text: p != null ? p.areaLabel.replaceAll(RegExp('[^0-9]'), '') : '');
    _priceController = TextEditingController(text: p != null ? p.priceLabel.replaceAll(RegExp('[^0-9]'), '') : '');
    _selectedType = p?.propertyType ?? propertyTypeOptions.first;
    _imagePaths = List.of(p?.imagePaths ?? const []);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _locationController.dispose();
    _areaController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  Future<void> _pickImages() async {
    // Gallery only — picking from the camera needs an extra Android
    // manifest permission this project doesn't declare yet.
    final picked = await ImagePicker().pickMultiImage(imageQuality: 80);
    if (picked.isNotEmpty) {
      setState(() => _imagePaths.addAll(picked.map((x) => x.path)));
    }
  }

  void _removeImageAt(int index) {
    setState(() => _imagePaths.removeAt(index));
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _submitting = true);
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    setState(() => _submitting = false);

    final property = MarketerProperty(
      id: widget.existingProperty?.id ?? 'prop-${DateTime.now().millisecondsSinceEpoch}',
      title: _titleController.text.trim(),
      propertyType: _selectedType,
      location: _locationController.text.trim(),
      areaLabel: '${_areaController.text.trim()} م²',
      priceLabel: '${_priceController.text.trim()} ج.م',
      imagePaths: _imagePaths,
    );
    if (_isEditMode) {
      updateMarketerProperty(property);
    } else {
      addMarketerProperty(property);
    }

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.check_circle, color: AppColors.primary),
            const SizedBox(width: 8),
            Text(LocaleKeys.propertySavedSuccessTitle.tr(), style: AppTextStyles.heading4),
          ],
        ),
        content: Text(
          (_isEditMode ? LocaleKeys.propertyUpdatedSuccessDesc : LocaleKeys.propertyAddedSuccessDesc).tr(),
          style: AppTextStyles.bodyRegular,
          textAlign: TextAlign.start,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(), child: Text(LocaleKeys.okButton.tr())),
        ],
      ),
    );
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  Future<void> _confirmDelete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text(LocaleKeys.deletePropertyConfirmTitle.tr(), style: AppTextStyles.heading4),
        content: Text(LocaleKeys.deletePropertyConfirmDesc.tr(), style: AppTextStyles.bodyRegular, textAlign: TextAlign.start),
        actions: [
          TextButton(onPressed: () => Navigator.of(dialogContext).pop(false), child: Text(LocaleKeys.cancelButton.tr())),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(LocaleKeys.deletePropertyButton.tr(), style: const TextStyle(color: AppColors.error)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      final id = widget.existingProperty?.id;
      if (id != null) deleteMarketerProperty(id);
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text((_isEditMode ? LocaleKeys.editPropertyTitle : LocaleKeys.addPropertyTitle).tr(), style: AppTextStyles.heading3),
        leading: const AppBackButton(),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              MultiImagePickerField(
                imagePaths: _imagePaths,
                onAdd: _pickImages,
                onRemove: _removeImageAt,
                label: LocaleKeys.propertyPhotoLabel.tr(),
              ),
              const SizedBox(height: 20),
              ValidatedTextField(controller: _titleController, label: LocaleKeys.offerPropertyTitleLabel.tr()),
              const SizedBox(height: 16),
              PropertyTypeChips(selected: _selectedType, onChanged: (type) => setState(() => _selectedType = type)),
              const SizedBox(height: 16),
              ValidatedTextField(controller: _locationController, label: LocaleKeys.propertyLocationLabel.tr()),
              const SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: ValidatedTextField(controller: _areaController, label: LocaleKeys.specArea.tr(), keyboardType: TextInputType.number),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ValidatedTextField(controller: _priceController, label: LocaleKeys.propertyPriceLabel.tr(), keyboardType: TextInputType.number),
                  ),
                ],
              ),
              const SizedBox(height: 28),
              AppPrimaryButton(
                label: (_isEditMode ? LocaleKeys.savePropertyButton : LocaleKeys.addPropertySubmit).tr(),
                icon: Icons.check,
                isLoading: _submitting,
                onPressed: _submitting ? null : _submit,
              ),
              if (_isEditMode) ...[
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: _confirmDelete,
                  icon: const Icon(Icons.delete_outline, size: 18),
                  label: Text(LocaleKeys.deletePropertyButton.tr()),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.error,
                    side: const BorderSide(color: AppColors.error),
                    minimumSize: const Size.fromHeight(48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

