import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import '../../../../config/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../core/shared/widgets/app_primary_button.dart';
import '../models/property_request.dart';
import '../widgets/category_chip.dart';
import '../widgets/request_card.dart';
import '../../../../generated/locale_keys.g.dart';

/// Content for the "Home" tab only — no Scaffold/bottom nav here.
/// [ClientShellScreen] owns those and swaps this in via BottomBarCubit.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          _TopBar(),
          const SizedBox(height: 24),
          _SearchBar(onTap: () => Navigator.pushNamed(context, AppRoutes.search)),
          const SizedBox(height: 24),
          _CategoriesRow(
            onCategoryTap: (category) => Navigator.pushNamed(context, AppRoutes.search, arguments: category),
          ),
          const SizedBox(height: 24),
          _SectionHeader(onViewAllTap: () => Navigator.pushNamed(context, AppRoutes.search),),
          const SizedBox(height: 16),
          ...mockRecentRequests.map(
            (r) => Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: RequestCard(
                request: r,
                onTap: () => Navigator.pushNamed(context, AppRoutes.requestDetails, arguments: r.id),
              ),
            ),
          ),
          const SizedBox(height: 8),
          AppPrimaryButton(
            label: LocaleKeys.createRequestButton.tr(),
            icon: Icons.add,
            onPressed: () => Navigator.pushNamed(context, AppRoutes.createRequestLocation),
          ),
        ],
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(LocaleKeys.greetingHi.tr(), style: AppTextStyles.heading4, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 4),
            Text(LocaleKeys.homeSubtitle.tr(), style: AppTextStyles.bodyRegular, overflow: TextOverflow.ellipsis),
          ],
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: AppColors.background,
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children:  [
              Icon(Icons.expand_more, size: 14, color: AppColors.textSecondary),
              SizedBox(width: 4),
              Text('القاهرة', style: AppTextStyles.bodySmall),
            ],
          ),
        ),
        const SizedBox(width: 8),
        Stack(
          clipBehavior: Clip.none,
          children: [
            const Icon(Icons.notifications_outlined, color: AppColors.textPrimary),
            Positioned(
              right: -1,
              top: -1,
              child: Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(color: AppColors.error, shape: BoxShape.circle),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _SearchBar extends StatelessWidget {
  final VoidCallback onTap;
  const _SearchBar({required this.onTap});

  @override
  Widget build(BuildContext context) {
    // Opens the dedicated SearchScreen rather than filtering in place —
    // matches searchPlaceholder's copy ("search by city, area, or
    // property type") which needs its own text field and results list.
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 17, vertical: 16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              const Icon(Icons.search, size: 18, color: AppColors.textSecondary),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  LocaleKeys.searchPlaceholder.tr(),
                  style: AppTextStyles.bodyRegular,
                  textAlign: TextAlign.start,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoriesRow extends StatelessWidget {
  final ValueChanged<String> onCategoryTap;
  const _CategoriesRow({required this.onCategoryTap});

  @override
  Widget build(BuildContext context) {
    final categories = [
      (Icons.business_outlined, LocaleKeys.categoryOffice.tr()),
      (Icons.terrain_outlined, LocaleKeys.categoryLand.tr()),
      (Icons.hotel_outlined, LocaleKeys.categoryStudio.tr()),
      (Icons.villa_outlined, LocaleKeys.categoryVilla.tr()),
      (Icons.apartment_outlined, LocaleKeys.categoryApartment.tr()),
    ];
    // Extra height beyond the icon box + label so the label never
    // overflows the row (this was the source of the yellow/black
    // overflow stripes under the categories).
    return SizedBox(
      height: 104,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 16),
        itemBuilder: (context, index) {
          final (icon, label) = categories[index];
          // Tapping a category jumps straight to search pre-filtered
          // by it, instead of doing nothing as before.
          return CategoryChip(icon: icon, label: label, onTap: () => onCategoryTap(label));
        },
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final VoidCallback onViewAllTap;
  const _SectionHeader({required this.onViewAllTap});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        GestureDetector(
          onTap: onViewAllTap,
          child: Text(LocaleKeys.viewAll.tr(), style: AppTextStyles.bodySmall.copyWith(color: AppColors.primaryDark)),
        ),
        Flexible(
          child: Text(
            LocaleKeys.recentRequestsTitle.tr(),
            style: AppTextStyles.heading4,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.start,
          ),
        ),
      ],
    );
  }
}
